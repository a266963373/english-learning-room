import { HttpError, requireValue } from './lib/errors.js';
import { validateAssessment, assessmentEntries } from './lib/assessment.js';
export const LANGUAGE_INFO={en:{name:'英语',suggestedStage:2}};
export function knownLanguage(id){requireValue(id==='en','此离线版只提供英语。');return id;}
export function knownStage(stage){requireValue(Number.isInteger(stage)&&stage>=1&&stage<=4,'训练必须为 1–4。');return stage;}
export class OfflineContent{
  constructor(document){this.document=document;this.course=document.course;this.measurement=validateAssessment(document.assessment,'en');this.index=new Map([...this.course.entries,...assessmentEntries(this.measurement)].map(e=>[e.id,e]));}
  pack(id){knownLanguage(id);return this.course;}
  assessment(id){knownLanguage(id);return this.measurement;}
  assessmentEntries(id){return assessmentEntries(this.assessment(id));}
  words(id){return [...this.eligible(id,2),...this.assessmentEntries(id)];}
  entry(id,entryId){knownLanguage(id);const entry=this.index.get(entryId);if(!entry)throw new HttpError(404,'entry_not_found','词条不存在。');return entry;}
  assistance(id,entry){knownLanguage(id);return entry;}
  eligible(id,stage){return this.pack(id).entries.filter(e=>stage===3?Boolean(e.sentence?.text):stage===4?Boolean(e.output?.prompts&&e.output.references?.length):true);}
}
