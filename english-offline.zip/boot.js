import { OfflineEngine, CACHE_PREFIX } from './engine.js';
import { openDatabase } from './store.js';
import { sha256 } from './crypto.js';
import { exportBackup, readBackup, restoreBackup } from './backup.js';
const base=new URL('./',location.href),nativeFetch=window.fetch.bind(window),shell=document.querySelector('.app-shell');
const panel=document.createElement('main');panel.className='installer';panel.innerHTML='<p>LANGUAGE ROOM · ENGLISH</p><h1>英语，随身学。</h1><p>1000 个词条、复习安排和音频下载到这台设备。日常学习无需登录或联网。</p><p>iPhone：先在 Safari 中选择“分享 → 添加到主屏幕”，再从主屏幕打开并下载。学习记录保存在当前设备；换设备请使用备份。</p><progress id="install-progress" max="1" value="0"></progress><p id="install-status" role="status">正在检查离线环境…</p><button type="button" id="download-course" class="primary" disabled>下载英语学习包</button><p>包含词汇水平校准；句子与输出素材各 45 条，后续可更新。</p>';document.body.append(panel);
const status=panel.querySelector('#install-status'),progress=panel.querySelector('progress'),download=panel.querySelector('button');let registration,engine,cache,release,documentPack,localPortable=false;
const message=text=>{status.textContent=text;};
function saveFile(blob,name){const url=URL.createObjectURL(blob),link=document.createElement('a');link.href=url;link.download=name;document.body.append(link);link.click();link.remove();setTimeout(()=>URL.revokeObjectURL(url),60000);}
function backupControls(){
  const controls=document.createElement('div');controls.className='offline-controls';controls.innerHTML='<button type="button" id="export-backup">导出备份</button><button type="button" id="import-backup">导入备份</button><input type="file" id="backup-file" accept="application/json,.json" hidden><small>进度和录音只保存在本机。请定期导出备份到“文件”；清除网站数据会删除本机存档。</small><span id="backup-status" role="status"></span>';
  document.querySelector('#settings-dialog .panel-heading').after(controls);const feedback=controls.querySelector('#backup-status');let backupBusy=false;
  controls.querySelector('#export-backup').onclick=async()=>{if(backupBusy)return;backupBusy=true;try{saveFile(await exportBackup(engine),`english-backup-${new Date().toISOString().slice(0,10)}.json`);feedback.textContent='已生成备份，请保存到“文件”。';}catch(e){feedback.textContent=e.message;}finally{backupBusy=false;}};
  controls.querySelector('#import-backup').onclick=()=>{if(!backupBusy)controls.querySelector('input').click();};
  controls.querySelector('input').onchange=async event=>{const file=event.target.files[0];event.target.value='';if(!file||backupBusy)return;backupBusy=true;try{const payload=await readBackup(file,engine);if(!confirm('导入将替换当前英语进度和录音。继续前会先导出当前备份，请将其保存到“文件”。是否继续？'))return;saveFile(await exportBackup(engine),`english-before-import-${Date.now()}.json`);await restoreBackup(engine,payload);location.reload();}catch(e){feedback.textContent=`未导入：${e.message}`;}finally{backupBusy=false;}};
}
async function launch(){
  const db=await openDatabase();engine=await new OfflineEngine(db,documentPack,base).init();
  window.fetch=(input,options={})=>{const url=new URL(typeof input==='string'?input:input.url,location.href);if(url.origin===location.origin&&url.pathname.startsWith('/api/'))return engine.handle(url,options);return nativeFetch(input,options);};
  window.englishOffline={engine,release};shell.hidden=false;panel.remove();backupControls();
  window.addEventListener('storage',event=>{if(event.key==='english-offline-import-id'){window.englishOffline.restoring=true;location.reload();}});
  const indicator=document.createElement('div');indicator.className='offline-status';indicator.textContent=`英语离线版 · ${documentPack.course.entries.length} 词 · 音频已下载`;shell.querySelector('.learning-tools').append(indicator);
  await import('./app.js');
  try{await navigator.storage?.persist?.();}catch{}
  // Keep the active/waiting worker's caches; deleting an update's cache would
  // strand other tabs. Updates switch only after an explicit user action.
  const update=document.createElement('button');update.type='button';update.className='quiet';update.textContent='有更新 · 安装新版';update.hidden=true;indicator.append(update);
  const notify=()=>{update.hidden=!registration.waiting;};notify();registration.addEventListener('updatefound',()=>{registration.installing?.addEventListener('statechange',notify);});
  update.onclick=()=>{if(registration.waiting&&confirm('更新会重新打开学习室，学习记录会保留。请先结束录音，再继续。')){navigator.serviceWorker.addEventListener('controllerchange',()=>location.reload(),{once:true});registration.waiting.postMessage('activate-update');}};
}
async function downloadAudio(){
  download.disabled=true;let completed=0;const assets=release.audio,queue=[...assets];progress.max=assets.length;
  message(`下载中：0 / ${assets.length}。请保持页面打开。`);
  try{
    const worker=async()=>{while(queue.length){const asset=queue.shift(),url=new URL(asset.path,base);let response=await cache.match(url),bytes=response?await response.arrayBuffer():null;
      if(!bytes){response=await caches.match(url);if(response)bytes=await response.arrayBuffer();}
      if(!bytes||sha256(bytes)!==asset.sha256){response=await nativeFetch(url,{cache:'no-store'});if(!response.ok)throw new Error('下载失败；已完成部分会保留，可稍后继续。');bytes=await response.arrayBuffer();if(sha256(bytes)!==asset.sha256)throw new Error('音频校验失败，请重试下载。');}
      await cache.put(url,new Response(bytes,{headers:{'Content-Type':asset.type}}));
      completed++;progress.value=completed;message(`下载中：${completed} / ${assets.length}。请保持页面打开。`);}};
    const results=await Promise.allSettled([worker(),worker(),worker()]);const failure=results.find(r=>r.status==='rejected');if(failure)throw failure.reason;
    await cache.put(new URL('offline-ready',base),new Response(release.version));await launch();
  }catch(error){message(error.name==='QuotaExceededError'?'设备空间不足。请释放空间后继续下载。':error.message);download.disabled=false;download.textContent='继续下载';}
}
download.onclick=()=>void downloadAudio();
async function initialize(){
  try{
    if(!window.isSecureContext||!('serviceWorker'in navigator)||!('indexedDB'in window))throw new Error('请通过 HTTPS 安装网址打开；iPhone 不支持直接打开 ZIP 作为完整离线应用。');
    registration=await navigator.serviceWorker.register(new URL('service-worker.js',base),{scope:base.pathname,updateViaCache:'none'});
    if(!navigator.serviceWorker.controller)await new Promise((resolve,reject)=>{const timer=setTimeout(()=>finish(new Error('离线组件未能下载，请检查网络或设备空间后重试。')),60000),worker=registration.installing;const finish=error=>{clearTimeout(timer);navigator.serviceWorker.removeEventListener('controllerchange',controlled);worker?.removeEventListener('statechange',changed);error?reject(error):resolve();},controlled=()=>{if(navigator.serviceWorker.controller)finish();},changed=()=>{if(worker.state==='redundant'&&!registration.active)finish(new Error('离线组件下载失败，请联网重试。'));};navigator.serviceWorker.addEventListener('controllerchange',controlled);worker?.addEventListener('statechange',changed);controlled();});
    const releaseResponse=await nativeFetch(new URL('release.json',base));if(!releaseResponse.ok)throw new Error('学习包说明暂时无法加载，请联网后重试。');localPortable=releaseResponse.headers.get('X-English-Portable')==='1';release=await releaseResponse.json();cache=await caches.open(CACHE_PREFIX+release.version);
    if(localPortable){panel.querySelectorAll('p')[2].textContent='电脑便携版：教材和音频来自本机文件。准备完成后自动进入学习，使用期间请保留启动窗口。';download.textContent='导入本机英语包';}
    const courseResponse=await cache.match(new URL('english.json',base));if(!courseResponse)throw new Error('应用更新尚未完成，请刷新重试。');documentPack=await courseResponse.json();
    const ready=await cache.match(new URL('offline-ready',base));if(ready&&(await ready.text())===release.version){await launch();return;}
    const size=release.audio.reduce((n,x)=>n+x.bytes,0);message(localPortable?'正在准备本机英语包，不需要互联网。':`英语包音频约 ${(size/1024/1024).toFixed(1)} MB。下载完成后可离线学习。`);download.disabled=false;if(localPortable)await downloadAudio();
  }catch(error){message(error.message);download.disabled=false;download.textContent='重试';download.onclick=()=>location.reload();}
}
void initialize();
