# Japanese kana annotations

Generated locally using SudachiPy 0.7.0 and SudachiDict-core 20260723.1 (Works Applications and contributors), Apache License 2.0. Bundled license: Sudachi-Apache-2.0.txt.

Upstream: https://github.com/WorksApplications/sudachi.rs and https://github.com/WorksApplications/SudachiDict . Japanese source entries retain their existing Wiktionary/Kaikki and sentence attribution. Contextual readings are dictionary-generated annotations, with exact selected-source pronunciations preferred for headwords. They are not new original course translations.
