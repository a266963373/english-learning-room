# Dictionary data attribution

English Wiktionary contributors (CC BY-SA 4.0): https://en.wiktionary.org/wiki/Wiktionary:Copyrights
License: https://creativecommons.org/licenses/by-sa/4.0/

Selected unprocessed Wiktextract JSONL objects from Kaikki.org. Current local snapshot: English Wiktionary dump dated 2026-09-02, extracted 2026-09-28; Wiktextract commits 1a05e46 and e3d6d4e as reported on the raw export page. This snapshot is not a live dictionary.

Raw source page: https://kaikki.org/dictionary/rawdata.html
Raw gzip URL: https://kaikki.org/dictionary/raw-wiktextract-data.jsonl.gz
The gzip ETag, Last-Modified, byte size and SHA-256 are retained in content/cache/raw-meta.json and in every published pack's source manifest.

Tatu Ylonen: Wiktextract: Wiktionary as Machine-Readable Structured Data. Proceedings of LREC 2022, pp. 1317–1325, Marseille, 20–25 June 2022. https://github.com/tatuylonen/wiktextract

Changes: frequency-driven selection; exact root-language/root-word checks; selected dictionary senses and forms; explicit editorial POS/sense choices; grammatical surface tokens linked to separately extracted exact Korean hyphenated dictionary forms. Individual dictionary and lemma URLs are included with entries. Source text remains source data, and sentence-specific grammatical analyses are unavailable unless explicitly provided.

Wikimedia and Tatoeba media are separate works with separate licenses. Their file authors, licenses and description URLs are retained on each audio object. No dictionary license is assumed to cover a recording.
