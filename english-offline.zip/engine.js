import { Learning, initialState, publicState, patchState } from './lib/learning.js';
import { OfflineContent, knownLanguage } from './content.js';
import { OfflineStore } from './store.js';
import { randomUUID, sha256 } from './crypto.js';
import { requireValue, HttpError } from './lib/errors.js';
export const CACHE_PREFIX='language-room-english-';
export const initialEnglishState=()=>{const state=initialState();state.selectedLanguage='en';state.selectedStage=2;state.preferences.helperPairs.en=['zh'];return state;};
export class OfflineEngine{
  constructor(db,document,base=new URL('./',location.href),clock=()=>new Date()){this.document=document;this.base=base;this.content=new OfflineContent(document);this.store=new OfflineStore(db,initialEnglishState);this.cacheName=CACHE_PREFIX+document.version;this.media={available:(_id,e,kind)=>Boolean(document.audio[`${e.id}:${kind}`]),revision:(_id,e)=>({offlineAudio:['word','sentence'].map(kind=>document.audio[`${e.id}:${kind}`]?.sha256||null)})};this.learning=new Learning(this.store,this.content,this.media,clock);}
  async init(){await this.store.init();await this.learning.refreshContent();return this;}
  catalog(){const pack=this.content.course;return {languages:[{id:'en',name:'英语',availableStages:[1,2,3,4],entryCount:pack.entries.length,audioCount:pack.entries.length,wordAudioCount:pack.entries.length,sentenceCount:this.content.eligible('en',3).length,sentenceAudioCount:this.content.eligible('en',3).length,outputCount:this.content.eligible('en',4).length,assessmentAvailable:true,version:pack.version,sources:[...pack.sources,...this.content.measurement.sources],audioNote:'音频随英语包下载到本机；下载完成后可离线播放。'}]};}
  async handle(url,options={}){
    const parsed=new URL(url,this.base),path=parsed.pathname,method=options.method||'GET',data=()=>JSON.parse(options.body||'{}');
    try{
      await this.store.refresh();let result,status=200;
      if(path==='/api/catalog')result=this.catalog();
      else if(path==='/api/state'&&method==='GET')result=publicState(this.store.state,this.learning.clock(),this.content);
      else if(path==='/api/state'&&method==='PATCH')result=await this.store.transaction(s=>patchState(s,data(),this.learning.clock(),this.content));
      else if(path==='/api/session'&&method==='POST')result=await this.learning.start(data());
      else if(/^\/api\/session\/[A-Za-z0-9_-]+$/.test(path)&&method==='GET')result=await this.learning.get(path.split('/').at(-1));
      else if(path==='/api/assessment/session'&&method==='POST')result=await this.learning.startAssessment(data());
      else if(path==='/api/review'&&method==='POST')result=await this.learning.review(data());
      else if(path==='/api/undo'&&method==='POST')result=await this.learning.undo(data());
      else if(path==='/api/lookup'){
        const id=knownLanguage(parsed.searchParams.get('languageId')),entry=this.content.entry(id,parsed.searchParams.get('entryId')),sentenceId=parsed.searchParams.get('sentenceId');
        const sentence=sentenceId?this.content.course.entries.find(e=>e.sentence?.id===sentenceId)?.sentence:null;
        const tokens=sentence?.tokens?.filter(t=>t.entryId===entry.id||t.lemma===entry.lemma)||[];result={entry,context:sentenceId?{status:tokens.some(t=>t.function)?'annotated':'unavailable',tokens}:undefined};
      }else if(path==='/api/audio'){
        const id=knownLanguage(parsed.searchParams.get('languageId')),entryId=parsed.searchParams.get('entryId'),kind=parsed.searchParams.get('kind')||'word',sessionId=parsed.searchParams.get('sessionId'),taskId=parsed.searchParams.get('taskId');
        this.learning.validateAudioTask(id,entryId,sessionId,taskId);const record=this.document.audio[`${entryId}:${kind}`];requireValue(record,'此题没有打包音频。',404,'audio_unavailable');
        const cache=await caches.open(this.cacheName),response=await cache.match(new URL(record.path,this.base));requireValue(response,'音频未下载或已被清理，请联网重新下载英语包。',503,'audio_unavailable');
        const bytes=await response.arrayBuffer();requireValue(sha256(bytes)===record.sha256,'音频校验失败，请重新下载英语包。',422,'audio_mismatch');
        if(kind==='word')await this.learning.audioReady(id,entryId,record.metadata,sessionId,taskId);
        return new Response(bytes,{headers:{'Content-Type':record.type,'Cache-Control':'no-store'}});
      }else if(path==='/api/recording'&&method==='POST'){
        const blob=options.body,sessionId=parsed.searchParams.get('sessionId'),taskId=parsed.searchParams.get('taskId');requireValue(blob instanceof Blob&&blob.size>0&&blob.size<=8*1024*1024,'录音为空或超过 8 MB。',413,'recording_too_large');
        requireValue(['audio/webm','audio/mp4','audio/ogg','audio/wav','audio/mpeg'].includes(blob.type.split(';')[0]),'录音格式不支持。',415,'unsupported_media');
        const id=randomUUID(),url=new URL(`local-recording/${id}`,this.base).href;
        result=await this.store.transaction(s=>{const session=s.sessions[sessionId];requireValue(session?.task?.id===taskId&&session.stage===4,'录音须关联当前输出题。',409,'task_conflict');const record={id,sessionId,taskId,type:blob.type,url,createdAt:this.learning.clock().toISOString()};s.recordings[id]=record;return record;},{id,blob});status=201;
      }else throw new HttpError(404,'not_found','此离线版没有此接口。');
      return new Response(JSON.stringify(result),{status,headers:{'Content-Type':'application/json','Cache-Control':'no-store'}});
    }catch(error){return new Response(JSON.stringify({error:{code:error.code||'offline_error',message:error.name==='QuotaExceededError'?'手机空间不足，未保存此次操作。请先导出备份并释放空间。':error.message}}),{status:error.status||500,headers:{'Content-Type':'application/json','Cache-Control':'no-store'}});}
  }
}
