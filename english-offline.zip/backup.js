import { requireValue } from './lib/errors.js';
import { sha256 } from './crypto.js';
const UUID=/^[a-f0-9-]{36}$/i;
function encode(bytes){let text='';for(let offset=0;offset<bytes.length;offset+=16384)text+=String.fromCharCode(...bytes.subarray(offset,offset+16384));return btoa(text);}
export async function exportBackup(engine){
  const snapshot=await engine.store.snapshot(),recordings=[];
  for(const row of snapshot.recordings){const bytes=new Uint8Array(await row.blob.arrayBuffer());recordings.push({id:row.id,type:row.blob.type,sha256:sha256(bytes),data:encode(bytes)});}
  let ui={};try{ui=JSON.parse(localStorage.getItem('english-offline-ui')||'{}');}catch{}
  const payload={format:'language-room-english-backup',version:1,exportedAt:new Date().toISOString(),courseVersion:engine.document.version,state:snapshot.state,ui,recordings};
  return new Blob([JSON.stringify(payload)],{type:'application/json'});
}
export async function readBackup(file,engine){
  requireValue(file.size<=128*1024*1024,'备份超过 128 MB，不能直接导入。');
  const payload=JSON.parse(await file.text());requireValue(payload.format==='language-room-english-backup'&&payload.version===1,'这不是英语离线版的有效备份。');
  const s=payload.state;requireValue(s?.schemaVersion===1&&s.selectedLanguage==='en'&&[1,2,3,4].includes(s.selectedStage)&&Object.keys(s.languages||{}).join(',')==='en','备份存档无效。');
  for(const key of ['sessions','activeSessions','requests','receipts','recordings','jobs','preferences'])requireValue(s[key]&&typeof s[key]==='object'&&!Array.isArray(s[key]),'备份缺少必要字段。');
  const l=s.languages.en;requireValue(Array.isArray(l.reviews)&&l.cards&&l.rewards&&l.stagePositions&&Number.isFinite(l.xp),'备份学习记录无效。');
  requireValue(Number.isInteger(s.preferences.dailyGoal)&&s.preferences.dailyGoal>=1&&s.preferences.dailyGoal<=1000&&s.preferences.helpers&&s.preferences.dailyGoals,'备份设置无效。');
  for(const session of Object.values(s.sessions))requireValue(UUID.test(session.id)&&session.languageId==='en'&&[1,2,3,4].includes(session.stage)&&(!session.task||UUID.test(session.task.id)),'备份会话无效。');
  for(const review of l.reviews)requireValue([1,2,3,4].includes(review.rating)&&Number.isFinite(Date.parse(review.reviewedAt))&&review.entryId?.startsWith('en:'),'备份评分无效。');
  for(const card of Object.values(l.cards))requireValue(Number.isFinite(Date.parse(card.due))&&[0,1,2,3].includes(card.state)&&['stability','difficulty','elapsed_days','scheduled_days','reps','lapses'].every(key=>Number.isFinite(card[key])),'备份复习安排无效。');
  requireValue(Array.isArray(payload.recordings)&&payload.recordings.length===Object.keys(s.recordings).length,'备份录音数量不匹配。');const ids=new Set(),recordings=[];
  for(const row of payload.recordings){requireValue(UUID.test(row.id)&&!ids.has(row.id)&&Object.hasOwn(s.recordings,row.id)&&typeof row.data==='string'&&row.data.length<=12*1024*1024,'备份录音无效。');ids.add(row.id);const bytes=Uint8Array.from(atob(row.data),c=>c.charCodeAt(0));requireValue(bytes.length>0&&bytes.length<=8*1024*1024&&sha256(bytes)===row.sha256&&['audio/webm','audio/mp4','audio/ogg','audio/wav','audio/mpeg'].includes(row.type?.split(';')[0]),'备份录音校验失败。');s.recordings[row.id].url=new URL(`local-recording/${row.id}`,engine.base).href;recordings.push({id:row.id,blob:new Blob([bytes],{type:row.type})});}
  // Never restore old-origin URLs or a browser's "already heard" flags. The
  // restored task still must actually play before a sound rating is enabled.
  const ui=payload.ui&&typeof payload.ui==='object'&&!Array.isArray(payload.ui)?payload.ui:{};
  ui.items||={};for(const item of Object.values(ui.items)){item.audioHeard=false;if(item.recordServerURL){const id=item.recordServerURL.split('/').at(-1);item.recordServerURL=ids.has(id)?new URL(`local-recording/${id}`,engine.base).href:null;}}
  delete ui.refreshJob;delete ui.pendingUndos;
  return {state:s,recordings,ui};
}
export async function restoreBackup(engine,payload){await engine.store.restore(payload.state,payload.recordings);if(window.englishOffline)window.englishOffline.restoring=true;localStorage.setItem('english-offline-ui',JSON.stringify(payload.ui));localStorage.setItem('english-offline-import-id',globalThis.crypto.randomUUID());await engine.learning.refreshContent();}
